#include <stdio.h>
#include <stdlib.h>
#include <math.h>
float funcao(int n){
  float sum = 0;
  for (int k =1; k <= n; k++){
    sum = (k/pow(k,2)) * (pow(-1.0, k+1.0));
  }
  return sum;
}

int main(){
  int val;
  printf("Digite o valor de n: ");
  scanf("%d", &val);
  printf("val: %f\n", funcao(val));
  return 0;
}