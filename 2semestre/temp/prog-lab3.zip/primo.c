#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

bool primo(int val) {
  for (int i = 2; i <= val/2; i++) {
    
    if (val % i == 0 && val != i) {
      return false;
    }
  }

  return true;
}

int main() {
  int val1, val2;
  printf("Digite o primeiro valor: ");
  scanf("%d", &val1);
  printf("Digite o segundo valor: ");
  scanf("%d", &val2);

  int primosVal1[val1], lastVal1 = 0;

  for (int i = 2; i <= val1; i++) {
    if (val1 % i == 0){
      if (primo(i)) {
        primosVal1[lastVal1] = i;
        lastVal1++;
      }
    }
  }

  int primosVal2[val2], lastVal2 = 0;

  for (int i = 2; i <= val2; i++) {
    if (val2 % i == 0) {
      if (primo(i)){
        primosVal2[lastVal2] = i;
        lastVal2++;
      }
    }
  }
  int * semelhantes = malloc(sizeof(int) * 20);

  for (int i = 0; true; i++) {
    if (i > lastVal1 && i > lastVal2)
      break;
    for (int j = 0; primosVal1[j] <= primosVal2[i]; j++) {
      if (primosVal1[j] == primosVal2[i]) {
        printf("%d ", primosVal1[j]);
      }
    }
  }
  printf("\n");

  return 0;
}